package Practica2;
import java.util.Scanner;
public class Practica2 {
	public static void main(String[]args) {
		Scanner teclado=new Scanner(System.in );
		int a;
		int b;
		System.out.print("Ingrese el primer numero:");
		a=teclado.nextInt();
		System.out.print("Ingrese el segundo numero:");
		b=teclado.nextInt();
		
		if(a>b) {
			System.out.print("El orden correcto es:"+a+"->"+b);
			}
		else {
			System.out.print("El orden de mayor a menor es:"+b+"->"+a);

		}
	}

}
