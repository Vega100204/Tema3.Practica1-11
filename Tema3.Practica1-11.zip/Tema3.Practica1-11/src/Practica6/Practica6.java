package Practica6;

import java.util.Scanner;

public class Practica6 {
	
	
	enum NotasPosibles{
		MUY_DEFICIENTE,INSUFICIENTE,SUFICIENTE,BIEN,NOTABLE,SOBRESALIENTE;
	}

	
	public static void main (String[]arg) {
		Scanner scanner;
		int numero = 0; 

		scanner = new Scanner(System.in);
		System.out.println("Introduce un numero");
		numero = scanner.nextInt();
	
		switch(numero) {
		case 1:
			break;
		case 2:
			System.out.println("Tiene un muy deficiente");
		break;
		case 3:
		case 4:
			System.out.println("Tiene un insuficinete");
			// estas supenso
			break;
		case 5:
			System.out.println("Tiene un suficiente");
			break;
		case 6:
			System.out.println("Tiene un bien");
			break;
		case 7:
		case 8:
			System.out.println("Tiene un notable");
			break;
		case 9:
		case 10:
			System.out.println("Tiene un sobresaliente");
			break;
		default:
			//no existe esa nota
			
		}
		
			
		}
	
}



