package Practica7;

import java.util.Scanner;

public class Practica7 {
	



public static void main(String[]arg) {
int dia;
int mes;
int año;
Scanner teclado = new Scanner(System.in);
System.out.print("Introducir dia:");
dia=teclado.nextInt();
System.out.print("Introducir mes:");
mes=teclado.nextInt();
System.out.print("Introducir año:");
año=teclado.nextInt();
if(dia >=1 && dia <=30) {
	
}
if (mes >=1 && mes <=12) {
	
}
if (año !=0) {
	System.out.println("Fecha correcta");
}
else {
	System.out.println("Año incorrecto");
}
 if (mes !=0) {
	 System.out.println("Fecha correcta");
 }
 else {	
	System.out.println("Mes incorrecto");

}
 if (dia !=0) {
	 System.out.println("Fecha correcta");
  }
 else {
		System.out.println("Dia incorrecto");
 
 }
}}
