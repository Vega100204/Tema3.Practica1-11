package Practica8;

import java.util.Scanner;

public class Practica8 {
	public static void main (String[]arg) {
		Scanner teclado = new Scanner(System.in);
		int mes;
		System.out.print("Introducir numero de mes:");
		mes=teclado.nextInt();
		if(mes < 1 && mes>12) {
			System.out.println("Mes inorrecto");
		}
		else {
	}
		switch(mes) {
		case 1: System.out.print("Enero");
				break;
		case 2: System.out.print("Febrero");
				break;
		case 3: System.out.print("Marzo");
				break;
		case 4: System.out.print("Abril");
				break;
		case 5: System.out.print("Mayo");
				break;
		case 6: System.out.print("Junio");
				break;
		case 7: System.out.print("Julio");
				break;
		case 8: System.out.print("Agosto");
				break;
		case 9: System.out.print("Septiembre");
				break;
		case 10: System.out.print("Octubre");
				break;
		case 11: System.out.print("Noviembre");
				break;
		case 12: System.out.print("Diciembre");
				break;
		}
		if(mes == 4 && mes == 6 && mes == 9 && mes == 11) {
			System.out.println("es un mes de 30 dias");
		}
		else {
		}
		if(mes == 2) {
			System.out.println("es un mes de 28 dias");
		}
		else {
			System.out.println("es un mes de 31 dias");
		}
}
}
