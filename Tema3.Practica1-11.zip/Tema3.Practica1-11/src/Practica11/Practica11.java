package Practica11;

import java.util.Scanner;

public class Practica11 {
	public static void main (String[]arg) {
		String dia;
		Scanner input = new Scanner(System.in);
		dia = input.nextLine();
		
		String dia_converted = dia.toLowerCase();
		switch(dia_converted) {
		case "lunes":
			System.out.println("1");
			break;
		case "martes":
			System.out.println("2");
			break;
		case "miercoles":
			System.out.println("3");
			break;
		case "jueves":
			System.out.println("4");
			break;
		case "viernes":
			System.out.println("5");
			break;
		case "sabado":
			System.out.println("6");
			break;
		case "domingo":
			System.out.println("7");
			break;
		}
		}
}

