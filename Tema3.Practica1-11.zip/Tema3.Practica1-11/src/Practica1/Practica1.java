package Practica1;

import java.util.Scanner;

public class Practica1 {
	public static void main (String[] arg) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Primer numero:");
		int num1=sc.nextInt();
		System.out.print("Segundo numero:");
		int num2 = sc.nextInt();
		int x = num1 % num2;
		
		if (x==0) {
			System.out.println("El resultado es multiplo");
			
		}
		else {
			System.out.println("El resultado no es multiplo con que esta mal");
			
		}
		

		
		
		
	}
	

}
