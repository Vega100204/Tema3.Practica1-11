package Practica5;

import java.util.Scanner;

public class Practica5 {
	public static void main (String[]arg) {
		int numero;
		Scanner teclado = new Scanner(System.in);
	System.out.println("Introduce un numero e indica si es par o impar:");
	numero = teclado.nextInt();
	if (numero % 2==0) {
		System.out.println("Es par");
	}
	else {
		System.out.println("Es impar");
	}
	}

}
