package Practica4;

import java.util.Scanner;

public class Practica4 {
	public static void main (String[]arg) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Dime un numero entre el 0 y el 9999:");
		int num1 = sc.nextInt();
		
		if (num1<10) {
			System.out.println("Tiene 1 cifra");
		}
		else if(num1<100) {
			System.out.println("Tiene 2 cifra");

		}
		else if(num1<1000) {
			System.out.println("Tiene 3 cifra");

		}
		else if(num1<10000) {
			System.out.println("Tiene 4 cifra");

		}


	}
}
