package Practica10;

import java.util.Scanner;

public class Practica10 {
	public static void main (String[]args) {
		Scanner teclado = new Scanner(System.in);
		int numero,cuadrado;
		System.out.print("Introduce numero:");
		numero = teclado.nextInt();
		while (numero>=0) {
			cuadrado = numero*numero;
			System.out.println(numero+"² es igual a "+cuadrado);
			System.out.println("Introduce otra numero");
			numero = teclado.nextInt();
		}
	}
}